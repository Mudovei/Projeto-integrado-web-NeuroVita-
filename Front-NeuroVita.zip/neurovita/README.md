# NeuroVita — Angular + TypeScript

Telas de acesso do NeuroVita feitas em **Angular 21** com **TypeScript**.

## Como abrir no VS Code

1. Instale o **Node.js 20.19 ou mais novo** (recomendado: versão LTS em https://nodejs.org).
2. Abra esta pasta (`neurovita`) no VS Code.
3. No terminal do VS Code (menu **Terminal → Novo Terminal**), rode:

   ```bash
   npm install
   npm start
   ```

4. Abra **http://localhost:4200** no navegador.

Dica: o VS Code vai sugerir a extensão **Angular Language Service** — instale para ter
autocompletar nos arquivos `.html` dos componentes.

## Comandos

| Comando         | O que faz                                        |
| --------------- | ------------------------------------------------ |
| `npm start`     | Roda o site em modo desenvolvimento (porta 4200) |
| `npm run build` | Gera a versão final na pasta `dist/`             |
| `npm test`      | Roda os testes (regras da nova senha)            |

## Telas (rotas)

| Endereço           | Tela                              |
| ------------------ | --------------------------------- |
| `/`                | Login (tela inicial)              |
| `/esqueci-senha`   | Esqueci minha senha               |
| `/codigo`          | Digitar o código de 6 dígitos     |
| `/redefinir-senha` | Criar nova senha                  |
| `/psicologo`       | Início do psicólogo               |
| `/psicologo/pacientes`                         | Lista de pacientes        |
| `/psicologo/pacientes/:id`                     | Prontuário do paciente    |
| `/psicologo/pacientes/:id/:secao`              | Evoluções, laudos, encaminhamentos, avaliações e atestados |
| `/psicologo/pacientes/:id/:secao/novo`         | Novo documento            |
| `/psicologo/pacientes/:id/:secao/:docId`       | Ler um documento          |
| `/psicologo/pacientes/:id/:secao/:docId/editar`| Editar um documento       |
| `/psicologo/agenda`                            | Agenda semanal            |
| `/psiquiatra`      | Início do psiquiatra              |
| `/secretaria`      | Início da secretária              |
| `/admin`           | Início do administrador           |
| qualquer outro     | Página não encontrada (404)       |

## Login de teste (sem back-end)

Ao clicar no campo de e-mail aparece a lista de contas de teste. Senha de todas: `123456`.

| E-mail                    | Vai para       |
| ------------------------- | -------------- |
| `psicologo@neurovita.com`  | `/psicologo`   |
| `psiquiatra@neurovita.com` | `/psiquiatra`  |
| `secretaria@neurovita.com` | `/secretaria`  |
| `admin@neurovita.com`      | `/admin`       |

O e-mail não diferencia maiúsculas de minúsculas. Tudo isso fica em `shared/auth.ts`.

## Telas do psicólogo

Tudo funciona com dados em memória (somem ao recarregar a página):
- `shared/clinica/clinica.ts` guarda pacientes e documentos. Trocar por chamadas à API.
- `shared/clinica/dados-clinica.ts` e `shared/dados-agenda.ts` têm os dados fictícios.
- `shared/clinica/secoes.ts` define textos e botões de cada seção do prontuário.
- Upload de arquivos usa endereços temporários do navegador (`URL.createObjectURL`): no back-end,
  enviar o arquivo de verdade.
- O editor de texto (`shared/editor-texto`) usa `document.execCommand`. O texto é limpo por
  `limparHtml` (`shared/util.ts`); repetir a limpeza no servidor.

## Ligando ao back-end

- **Login:** trocar o conteúdo de `shared/auth.ts` por uma chamada à API (o servidor deve devolver o
  perfil). Remover a lista de e-mails de teste em `pages/login`.
- **Dados das telas:** `shared/dados-demo.ts` tem tudo que é fictício (agenda, consultas, cards,
  calendário). Os componentes só recebem os dados, então basta devolver o mesmo formato.
- **O que muda em cada perfil** (menu, botões, banner...) fica em `shared/perfil.ts`.
- Os pontos que faltam ligar estão marcados com `TODO` nos arquivos.

## Estrutura

```text
src/
  index.html                 -> página base (fonte Poppins, ícone)
  styles.css                 -> todo o visual (cores, campos, botões)
  app/
    app.routes.ts            -> lista de telas e seus endereços
    app.config.ts            -> configuração do Angular
    shared/
      auth.ts                -> login de teste (trocar pela API)
      perfil.ts              -> os 4 perfis e o que muda em cada um
      dados-demo.ts          -> dados fictícios das telas iniciais
      menu-lateral/ cabecalho/ agenda-do-dia/ proximas-consultas/
      calendario/ cards-resumo/ banner/ avatar/ tag-diagnostico/ icone/
      auth-card/             -> moldura com fundo, cartão e logo
      campo-senha/           -> campo de senha com botão de mostrar/ocultar
      validacao-senha.ts     -> regras da nova senha (+ testes .spec.ts)
    pages/
      login/
      esqueci-senha/
      codigo/
      redefinir-senha/
      painel-inicio/         -> tela inicial dos 4 perfis
      nao-encontrada/
public/img/                  -> logo, fundo e ícone do site
```

## Observação

Login, envio de código e redefinição de senha ainda são **demonstrativos**: não
autenticam contas nem enviam e-mails. Os pontos para ligar a um servidor estão marcados
com `TODO` nos arquivos `.ts` das páginas.
